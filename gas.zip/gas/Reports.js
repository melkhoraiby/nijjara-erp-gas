function nijjaraCanUseExecutiveReport_(session) {
  if (!session) return false;
  return nijjaraHasAccess_(session, 'financialReporting', 'view') ||
    nijjaraHasAccess_(session, 'reportExtraction', 'view') ||
    nijjaraHasAccess_(session, 'reportDownloading', 'view') ||
    nijjaraHasAccess_(session, 'businessAnalysisReporting', 'view');
}

function nijjaraGetExecutiveReport(sessionToken) {
  var session = nijjaraGetSession(sessionToken);
  if (!session) throw new Error('Session expired.');
  if (!nijjaraCanUseExecutiveReport_(session)) {
    throw new Error('You do not have access to generate this report.');
  }
  return nijjaraBuildExecutiveReport_(session);
}

function nijjaraGetExecutiveReportPdf(sessionToken) {
  var session = nijjaraGetSession(sessionToken);
  if (!session) throw new Error('Session expired.');
  if (!nijjaraCanUseExecutiveReport_(session)) {
    throw new Error('You do not have access to download this report.');
  }
  var report = nijjaraBuildExecutiveReport_(session);
  var pdfBlob = nijjaraBuildExecutiveReportPdfBlob_(report);
  return {
    fileName: pdfBlob.getName(),
    mimeType: MimeType.PDF,
    base64: Utilities.base64Encode(pdfBlob.getBytes())
  };
}

function nijjaraEmailExecutiveReport(sessionToken, recipients) {
  var session = nijjaraGetSession(sessionToken);
  if (!session) throw new Error('Session expired.');
  if (!nijjaraCanUseExecutiveReport_(session)) {
    throw new Error('You do not have access to send this report.');
  }
  var recipientList = String(recipients || '')
    .split(/[;,]/)
    .map(function (item) { return String(item || '').trim(); })
    .filter(function (item) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(item); });
  if (!recipientList.length) {
    throw new Error('At least one valid email address is required.');
  }
  var report = nijjaraBuildExecutiveReport_(session);
  var pdfBlob = nijjaraBuildExecutiveReportPdfBlob_(report);
  MailApp.sendEmail({
    to: recipientList.join(','),
    subject: report.subject,
    body: report.plainText,
    htmlBody: report.html,
    attachments: [pdfBlob],
    name: NIJJARA_CONFIG.systemName
  });
  return {
    success: true,
    recipients: recipientList,
    sentAt: nijjaraNow_()
  };
}

function nijjaraBuildExecutiveReport_(session) {
  var timeZone = Session.getScriptTimeZone() || 'Africa/Cairo';
  var now = new Date();
  var today = Utilities.formatDate(now, timeZone, 'yyyy-MM-dd');
  var yearStart = Utilities.formatDate(new Date(now.getFullYear(), 0, 1), timeZone, 'yyyy-MM-dd');
  var timestamp = Utilities.formatDate(now, timeZone, 'yyyy-MM-dd_HH-mm');
  var generatedAt = Utilities.formatDate(now, timeZone, "yyyy-MM-dd'T'HH:mm:ss");
  var generatedAtDisplay = formatArabicDateTimeServer(now, timeZone);

  var projects = nijjaraRows_('PRJ_Projects');
  var projectMap = {};
  projects.forEach(function (row) {
    projectMap[String(row.Project_ID || '').trim()] = row;
  });

  var revenueChannels = nijjaraRows_('FIN_RevenueChannels');
  var revenueChannelMap = {};
  revenueChannels.forEach(function (row) {
    revenueChannelMap[String(row.RevChannel_ID || '').trim()] = row;
  });

  var allocationChannels = nijjaraRows_('FIN_AllocationChannels');
  var allocationChannelMap = {};
  allocationChannels.forEach(function (row) {
    allocationChannelMap[String(row.AlloChannel_ID || '').trim()] = row;
  });

  var expenses = nijjaraRows_('FIN_Expenses').filter(function (row) {
    return !!nijjaraInputDateValue_(row.Date || '');
  });
  var internalRevenue = nijjaraRows_('FIN_InternalRevenue').filter(function (row) {
    return !!nijjaraInputDateValue_(row.Date || '');
  });
  var projectRevenue = nijjaraRows_('FIN_Revenue').filter(function (row) {
    return !!nijjaraInputDateValue_(row.Date || '');
  });
  var payments = nijjaraRows_('PRJ_Payments').filter(function (row) {
    return !!nijjaraInputDateValue_(row.Payment_Date || '');
  });
  var custodyAccounts = nijjaraRows_('FIN_CustodyAccounts').filter(function (row) {
    return String(row.Is_Active).toLowerCase() !== 'false';
  });

  function inRange(value, from, to) {
    if (!value) return false;
    if (from && value < from) return false;
    if (to && value > to) return false;
    return true;
  }

  function sum(rows, field) {
    return rows.reduce(function (acc, row) {
      return acc + (Number(row[field] || 0) || 0);
    }, 0);
  }

  function amountValue(row, field) {
    return Number(row[field] || 0) || 0;
  }

  function bucketByLabel(rows, keyBuilder, amountField, labelBuilder) {
    var bucket = {};
    rows.forEach(function (row) {
      var key = String(keyBuilder(row) || '').trim() || 'UNASSIGNED';
      if (!bucket[key]) {
        bucket[key] = {
          key: key,
          label: labelBuilder(row, key),
          amount: 0,
          count: 0
        };
      }
      bucket[key].amount += amountValue(row, amountField);
      bucket[key].count += 1;
    });
    return Object.keys(bucket).map(function (key) { return bucket[key]; }).sort(function (left, right) {
      return right.amount - left.amount;
    });
  }

  function projectLabel(projectId) {
    var project = projectMap[String(projectId || '').trim()];
    return (project && (project.Project_Name_AR || project.Project_Name_EN || projectId)) || 'غير مرتبط بمشروع';
  }

  function revenueChannelLabel(channelId) {
    var channel = revenueChannelMap[String(channelId || '').trim()];
    return (channel && (channel.RevChannel_AR || channel.RevChannel_EN || channelId)) || 'قناة غير محددة';
  }

  function allocationChannelLabel(channelId) {
    var channel = allocationChannelMap[String(channelId || '').trim()];
    return (channel && (channel.AlloChannel_AR || channel.AlloChannel_EN || channelId)) || 'قناة غير محددة';
  }

  function formatArabicDateServer(value) {
    var dateOnly = nijjaraInputDateValue_(value || '');
    if (!dateOnly) return '—';
    var parts = dateOnly.split('-');
    if (parts.length !== 3) return dateOnly;
    var months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return Number(parts[2]) + ' ' + months[Math.max(0, Math.min(11, Number(parts[1]) - 1))] + ' ' + parts[0];
  }

  function formatArabicDateTimeServer(value, zone) {
    if (!value) return '—';
    var date = value instanceof Date ? value : new Date(value);
    if (isNaN(date.getTime())) return '—';
    var months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    var year = Utilities.formatDate(date, zone, 'yyyy');
    var month = Number(Utilities.formatDate(date, zone, 'M'));
    var day = Number(Utilities.formatDate(date, zone, 'd'));
    var hour24 = Number(Utilities.formatDate(date, zone, 'H'));
    var minute = Utilities.formatDate(date, zone, 'mm');
    var meridiem = hour24 >= 12 ? 'م' : 'ص';
    var hour12 = hour24 % 12;
    if (!hour12) hour12 = 12;
    return day + ' ' + months[Math.max(0, Math.min(11, month - 1))] + ' ' + year + ' - ' + hour12 + ':' + minute + ' ' + meridiem;
  }

  function custodyDisplayLabel(row) {
    var label = String(row.CustodyAccount_AR || row.Linked_ID || row.CustodyAccount_ID || '').trim();
    if (String(row.Linked_ID || '').trim() === 'EMP-002' || label.indexOf('مصطفى سبيع') !== -1) {
      return 'الخزنة الرئيسية';
    }
    label = label.replace(/^عهدة شريك\s*-\s*/g, '');
    label = label.replace(/^عهدة الموظف\s*-\s*/g, '');
    return label;
  }

  var ytdExpenses = expenses.filter(function (row) {
    return inRange(nijjaraInputDateValue_(row.Date || ''), yearStart, today);
  });
  var ytdInternalRevenue = internalRevenue.filter(function (row) {
    return inRange(nijjaraInputDateValue_(row.Date || ''), yearStart, today);
  });
  var ytdProjectRevenue = projectRevenue.filter(function (row) {
    return inRange(nijjaraInputDateValue_(row.Date || ''), yearStart, today);
  });

  var expensesByChannel = bucketByLabel(ytdExpenses, function (row) {
    return row.AlloChannel_ID || '';
  }, 'Amount', function (row, key) {
    return allocationChannelLabel(key);
  });

  var revenueByChannel = bucketByLabel(ytdInternalRevenue.concat(ytdProjectRevenue), function (row) {
    return row.RevChannel_ID || '';
  }, 'Amount', function (row, key) {
    return revenueChannelLabel(key);
  });

  var projectExpensesAllTime = {};
  expenses.forEach(function (row) {
    var projectId = String(row.Project_ID || '').trim();
    if (!projectId) return;
    projectExpensesAllTime[projectId] = (projectExpensesAllTime[projectId] || 0) + amountValue(row, 'Amount');
  });

  var paymentMetaByProject = {};
  payments.forEach(function (row) {
    var projectId = String(row.Project_ID || '').trim();
    if (!projectId) return;
    if (!paymentMetaByProject[projectId]) {
      paymentMetaByProject[projectId] = { count: 0, amount: 0 };
    }
    paymentMetaByProject[projectId].count += 1;
    paymentMetaByProject[projectId].amount += amountValue(row, 'Payment_Amount');
  });

  var activeProjectsPending = projects.filter(function (row) {
    var status = nijjaraNormalizeProjectStatus_(row.Project_Status || '');
    var isActive = String(row.Is_Active).toLowerCase() !== 'false';
    var remaining = Number(row.Amount_Remaining || 0) || 0;
    return isActive && status !== 'COMPLETED' && status !== 'CANCELLED' && remaining > 0;
  }).map(function (row) {
    var projectId = String(row.Project_ID || '').trim();
    var paymentMeta = paymentMetaByProject[projectId] || { count: 0, amount: 0 };
    return {
      projectId: projectId,
      projectName: row.Project_Name_AR || row.Project_Name_EN || projectId,
      startDate: formatArabicDateServer(row.Actual_Start_Date || row.Contract_Start_Date || row.Created_At || ''),
      budget: Number(row.Project_Budget || 0) || 0,
      totalExpenses: Number(projectExpensesAllTime[projectId] || 0) || 0,
      paymentsCount: paymentMeta.count,
      received: Number(row.Amount_Received || paymentMeta.amount || 0) || 0,
      remaining: Number(row.Amount_Remaining || 0) || 0
    };
  }).sort(function (left, right) {
    return right.remaining - left.remaining;
  });

  var custodyBalances = custodyAccounts.map(function (row) {
    return {
      label: custodyDisplayLabel(row),
      amount: Number(row.Current_Balance || 0) || 0,
      status: row.Status_Code || 'ACTIVE'
    };
  }).sort(function (left, right) {
    return Math.abs(right.amount) - Math.abs(left.amount);
  });

  var summary = {
    yearStart: yearStart,
    generatedAt: generatedAt,
    expensesYtdAmount: sum(ytdExpenses, 'Amount'),
    revenueYtdAmount: sum(ytdInternalRevenue, 'Amount') + sum(ytdProjectRevenue, 'Amount'),
    activeProjects: projects.filter(function (row) {
      var status = nijjaraNormalizeProjectStatus_(row.Project_Status || '');
      return String(row.Is_Active).toLowerCase() !== 'false' && status !== 'COMPLETED' && status !== 'CANCELLED';
    }).length
  };

  var report = {
    generatedAt: generatedAt,
    generatedAtDisplay: generatedAtDisplay,
    generatedBy: session.displayName || session.username,
    subject: 'تقرير نجارة التنفيذي - ' + generatedAtDisplay,
    fileName: 'Nijjara_DailyReport_' + timestamp + '.pdf',
    summary: summary,
    sections: {
      expensesByChannel: expensesByChannel,
      revenueByChannel: revenueByChannel,
      activeProjectsPending: activeProjectsPending,
      custodyBalances: custodyBalances
    }
  };
  report.whatsAppText = [
    'تقرير نجارة التنفيذي',
    'المصروفات منذ بداية السنة: ' + (summary.expensesYtdAmount || 0).toLocaleString('ar-EG') + ' ج.م',
    'الإيرادات منذ بداية السنة: ' + (summary.revenueYtdAmount || 0).toLocaleString('ar-EG') + ' ج.م',
    'المشاريع النشطة: ' + (summary.activeProjects || 0).toLocaleString('ar-EG')
  ].join('\n');
  report.html = nijjaraRenderExecutiveReportHtml_(report);
  report.plainText = [
    'التقرير التنفيذي اليومي - نجارة',
    'تاريخ الإنشاء: ' + generatedAtDisplay,
    'إجمالي المصروفات منذ بداية السنة: ' + summary.expensesYtdAmount,
    'إجمالي الإيرادات منذ بداية السنة: ' + summary.revenueYtdAmount,
    'عدد المشاريع النشطة: ' + summary.activeProjects
  ].join('\n');
  return report;
}

function nijjaraRenderExecutiveReportHtml_(report) {
  var summary = report.summary || {};
  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  function money(value) {
    return esc((Number(value || 0) || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' ج.م');
  }
  function count(value) {
    return esc((Number(value || 0) || 0).toLocaleString('ar-EG'));
  }
  function metricCard(title, value) {
    return '<article class="metric-card"><div class="metric-card__title">' + esc(title) + '</div><div class="metric-card__value">' + value + '</div></article>';
  }
  function barSection(title, rows, colorClass, amountLabel) {
    rows = Array.isArray(rows) ? rows : [];
    var maxAmount = rows.reduce(function (acc, row) { return Math.max(acc, Number(row.amount || 0) || 0); }, 1);
    return '<section class="panel"><h3>' + esc(title) + '</h3>' +
      (rows.length
        ? '<div class="bar-list">' + rows.map(function (row) {
            var width = Math.max(12, Math.round(((Number(row.amount || 0) || 0) / maxAmount) * 100));
            return '<article class="bar-list__item"><div class="bar-list__meta"><strong>' + esc(row.label || '—') + '</strong><span>' + count(row.count || 0) + ' سجل</span></div><div class="bar-list__track"><div class="bar-list__fill ' + esc(colorClass) + '" style="width:' + width + '%"></div></div><div class="bar-list__value">' + money(row.amount || 0) + '<small>' + esc(amountLabel || '') + '</small></div></article>';
          }).join('') + '</div>'
        : '<div class="empty">لا توجد بيانات متاحة.</div>') +
      '</section>';
  }
  function pendingProjectsTable(rows) {
    rows = Array.isArray(rows) ? rows : [];
    return '<section class="panel panel--wide"><h3>المشاريع النشطة ذات المبالغ غير المحصلة</h3>' +
      (rows.length
        ? '<table><thead><tr><th>المشروع</th><th>تاريخ البدء</th><th>إجمالي الميزانية</th><th>إجمالي المصروفات</th><th>عدد الدفعات</th><th>المبلغ المستلم</th><th>المبلغ المتبقي</th></tr></thead><tbody>' +
            rows.map(function (row) {
              return '<tr><td>' + esc(row.projectName || '—') + '</td><td>' + esc(row.startDate || '—') + '</td><td>' + money(row.budget || 0) + '</td><td>' + money(row.totalExpenses || 0) + '</td><td>' + count(row.paymentsCount || 0) + '</td><td>' + money(row.received || 0) + '</td><td>' + money(row.remaining || 0) + '</td></tr>';
            }).join('') +
          '</tbody></table>'
        : '<div class="empty">لا توجد مشاريع نشطة بها مبالغ غير محصلة حالياً.</div>') +
      '</section>';
  }
  function custodyTable(rows) {
    rows = Array.isArray(rows) ? rows : [];
    return '<section class="panel"><h3>أرصدة العهد الحالية</h3>' +
      (rows.length
        ? '<table><thead><tr><th>الحساب</th><th>الرصيد الحالي</th></tr></thead><tbody>' +
            rows.map(function (row) {
              return '<tr><td>' + esc(row.label || '—') + '</td><td>' + money(row.amount || 0) + '</td></tr>';
            }).join('') +
          '</tbody></table>'
        : '<div class="empty">لا توجد بيانات عهد متاحة.</div>') +
      '</section>';
  }

  return '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + esc(report.fileName || 'Nijjara_DailyReport') + '</title>' +
    '<style>@import url("https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap");' +
      'body{margin:0;padding:20px;background:#0f1014;color:#f6f7fb;font-family:"Cairo",Tahoma,sans-serif;}' +
      '.shell{max-width:1180px;margin:0 auto;background:linear-gradient(180deg,#171922 0%,#101218 100%);border:1px solid rgba(255,255,255,.08);border-radius:28px;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.36);}' +
      '.hero{position:relative;padding:30px 34px 26px;background:radial-gradient(circle at top right,rgba(193,67,94,.28),transparent 34%),radial-gradient(circle at top left,rgba(240,195,127,.12),transparent 28%),linear-gradient(135deg,#1c1e27 0%,#11131a 62%,#0d0f14 100%);overflow:hidden;}' +
      '.hero__grid{position:relative;display:grid;grid-template-columns:1fr auto;align-items:center;gap:18px;min-height:118px;}' +
      '.hero__title-block{display:grid;gap:8px;justify-items:end;text-align:right;z-index:1;}' +
      '.hero__report-title{font-size:34px;line-height:1.1;font-weight:900;letter-spacing:-.5px;}' +
      '.hero__report-date{font-size:14px;color:#d8dbe3;padding:8px 14px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);}' +
      '.hero__logo-mark{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-family:"Manrope","Cairo",sans-serif;font-size:44px;font-weight:900;letter-spacing:6px;color:#f3c67e;text-shadow:0 10px 28px rgba(0,0,0,.32);z-index:1;}' +
      '.hero__glow{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:320px;height:120px;border-radius:999px;background:radial-gradient(circle,rgba(243,198,126,.18) 0%,rgba(243,198,126,.05) 42%,transparent 75%);filter:blur(8px);pointer-events:none;}' +
      '.metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;padding:18px 18px 12px;}' +
      '.metric-card,.panel{border-radius:20px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);}' +
      '.metric-card{padding:16px 18px;}' +
      '.metric-card__title{font-size:13px;color:#c2c5d0;margin-bottom:8px;}' +
      '.metric-card__value{font-size:28px;font-weight:900;line-height:1.2;}' +
      '.content{display:grid;grid-template-columns:1.05fr .95fr;gap:12px;padding:12px 18px 18px;}' +
      '.stack{display:grid;gap:12px;}' +
      '.panel{padding:16px;}' +
      '.panel h3{margin:0 0 12px;font-size:17px;}' +
      '.panel--wide{grid-column:1 / -1;}' +
      '.bar-list{display:grid;gap:12px;}' +
      '.bar-list__item{display:grid;gap:8px;}' +
      '.bar-list__meta{display:flex;justify-content:space-between;gap:12px;font-size:13px;color:#c8cad2;}' +
      '.bar-list__track{height:12px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;}' +
      '.bar-list__fill{height:100%;border-radius:inherit;}' +
      '.bar-list__fill--rose{background:linear-gradient(90deg,#e16f8c,#a6365d);}' +
      '.bar-list__fill--gold{background:linear-gradient(90deg,#f2cb6f,#b8871b);}' +
      '.bar-list__value{display:flex;justify-content:space-between;align-items:center;font-size:14px;font-weight:800;}' +
      '.bar-list__value small{font-size:11px;color:#9da1ab;font-weight:600;}' +
      'table{width:100%;border-collapse:collapse;font-size:13px;}' +
      'th,td{padding:9px 8px;border-bottom:1px solid rgba(255,255,255,.07);text-align:right;vertical-align:top;}' +
      'th{color:#f0c37f;font-size:12px;white-space:nowrap;}' +
      '.empty{padding:16px 0;color:#a5a9b3;}' +
      '@media (max-width:920px){.metrics,.content{grid-template-columns:1fr}.hero__grid{grid-template-columns:1fr;justify-items:center}.hero__title-block{justify-items:center;text-align:center}.hero__logo-mark{position:relative;left:auto;top:auto;transform:none;order:-1;font-size:38px}.hero__glow{width:240px;height:100px}}' +
      '@media print{body{padding:0;background:#fff;color:#111}.shell{border:0;box-shadow:none;border-radius:0}.metric-card,.panel{break-inside:avoid}}' +
    '</style></head><body><div class="shell">' +
      '<section class="hero">' +
        '<div class="hero__grid">' +
          '<div class="hero__title-block"><div class="hero__report-title">الملخص اليومي والتحليل</div><div class="hero__report-date">' + esc(report.generatedAtDisplay || summary.generatedAt || report.generatedAt) + '</div></div>' +
          '<div class="hero__logo-mark" aria-label="NIJJARA">NIJJARA</div>' +
          '<div class="hero__glow"></div>' +
        '</div>' +
      '</section>' +
      '<section class="metrics">' +
        metricCard('إجمالي المصروفات منذ بداية السنة', money(summary.expensesYtdAmount || 0)) +
        metricCard('إجمالي الإيرادات منذ بداية السنة', money(summary.revenueYtdAmount || 0)) +
        metricCard('عدد المشاريع النشطة', count(summary.activeProjects || 0)) +
      '</section>' +
      '<section class="content">' +
        '<div class="stack">' +
          barSection('الإيرادات منذ بداية السنة حسب القنوات', report.sections.revenueByChannel, 'bar-list__fill--rose', 'إجمالي الإيراد') +
          custodyTable(report.sections.custodyBalances) +
        '</div>' +
        '<div class="stack">' +
          barSection('المصروفات منذ بداية السنة حسب القنوات', report.sections.expensesByChannel, 'bar-list__fill--gold', 'إجمالي المصروف') +
        '</div>' +
        pendingProjectsTable(report.sections.activeProjectsPending) +
      '</section>' +
    '</div></body></html>';
}

function nijjaraBuildExecutiveReportPdfBlob_(report) {
  var doc = DocumentApp.create(report.fileName.replace(/\.pdf$/i, ''));
  var body = doc.getBody();
  body.setAttributes({});
  var defaultTextAttributes = {};
  defaultTextAttributes[DocumentApp.Attribute.FONT_FAMILY] = 'Cairo';
  defaultTextAttributes[DocumentApp.Attribute.FONT_SIZE] = 11;
  body.editAsText().setAttributes(defaultTextAttributes);
  body.appendParagraph('التقرير التنفيذي اليومي').setHeading(DocumentApp.ParagraphHeading.TITLE);
  body.appendParagraph('تاريخ الإنشاء: ' + (report.generatedAtDisplay || report.generatedAt || '—'));
  body.appendParagraph('أُعد بواسطة: ' + (report.generatedBy || '—'));
  body.appendParagraph(' ');

  body.appendParagraph('المؤشرات الرئيسية').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendTable([
    ['البند', 'القيمة'],
    ['إجمالي المصروفات منذ بداية السنة', (Number(report.summary.expensesYtdAmount || 0) || 0).toLocaleString('ar-EG') + ' ج.م'],
    ['إجمالي الإيرادات منذ بداية السنة', (Number(report.summary.revenueYtdAmount || 0) || 0).toLocaleString('ar-EG') + ' ج.م'],
    ['عدد المشاريع النشطة', (Number(report.summary.activeProjects || 0) || 0).toLocaleString('ar-EG')]
  ]);

  body.appendParagraph(' ');
  body.appendParagraph('الإيرادات حسب القنوات').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendTable([['القناة', 'عدد السجلات', 'الإجمالي']].concat((report.sections.revenueByChannel || []).map(function (row) {
    return [row.label || '—', String(row.count || 0), (Number(row.amount || 0) || 0).toLocaleString('ar-EG') + ' ج.م'];
  })));

  body.appendParagraph(' ');
  body.appendParagraph('المصروفات حسب القنوات').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendTable([['القناة', 'عدد السجلات', 'الإجمالي']].concat((report.sections.expensesByChannel || []).map(function (row) {
    return [row.label || '—', String(row.count || 0), (Number(row.amount || 0) || 0).toLocaleString('ar-EG') + ' ج.م'];
  })));

  body.appendParagraph(' ');
  body.appendParagraph('المشاريع النشطة ذات المبالغ غير المحصلة').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendTable([['المشروع', 'تاريخ البدء', 'الميزانية', 'المصروفات', 'عدد الدفعات', 'المستلم', 'المتبقي']].concat((report.sections.activeProjectsPending || []).map(function (row) {
    return [
      row.projectName || '—',
      row.startDate || '—',
      (Number(row.budget || 0) || 0).toLocaleString('ar-EG') + ' ج.م',
      (Number(row.totalExpenses || 0) || 0).toLocaleString('ar-EG') + ' ج.م',
      String(row.paymentsCount || 0),
      (Number(row.received || 0) || 0).toLocaleString('ar-EG') + ' ج.م',
      (Number(row.remaining || 0) || 0).toLocaleString('ar-EG') + ' ج.م'
    ];
  })));

  body.appendParagraph(' ');
  body.appendParagraph('أرصدة العهد الحالية').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendTable([['الحساب', 'الرصيد الحالي']].concat((report.sections.custodyBalances || []).map(function (row) {
    return [row.label || '—', (Number(row.amount || 0) || 0).toLocaleString('ar-EG') + ' ج.م'];
  })));

  doc.saveAndClose();
  var file = DriveApp.getFileById(doc.getId());
  var pdfBlob = file.getAs(MimeType.PDF).setName(report.fileName || ('Nijjara_DailyReport_' + nijjaraNow_() + '.pdf'));
  file.setTrashed(true);
  return pdfBlob;
}
